export interface User{
    email:string;
    displayName: string;
    token: string
}

export interface Address{
    firstName: string;
    lastName: string;
    phone: string;
    birthday: string;
    favoriteExhibit: string;
    city: string;
    

}