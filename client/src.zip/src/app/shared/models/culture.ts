export interface Culture{
    id: number;
    name: string;
}