import { Component } from '@angular/core';
import { Exhibit } from 'src/app/shared/models/exhibit';
import { ExhibitsService } from '../exhibits.service';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbService } from 'xng-breadcrumb';

@Component({
  selector: 'app-exhibit-details',
  templateUrl: './exhibit-details.component.html',
  styleUrls: ['./exhibit-details.component.scss']
})
export class ExhibitDetailsComponent {
  exhibit?: Exhibit;
  quantity = 1;
  quantityInBasket = 0;

  constructor(private exhibitService: ExhibitsService, private activatedRoute: ActivatedRoute, 
    private bcService: BreadcrumbService) {
      this.bcService.set('@productDetails', ' ')
    }
  ngOnInit(): void {
   
  }

  
}
