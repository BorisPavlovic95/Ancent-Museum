import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExhibitsComponent } from './exhibits.component';

import { ExhibitDetailsComponent } from './exhibit-details/exhibit-details.component';
import { ExhibitItemComponent } from './exhibit-item/exhibit-item.component';
import { ExhibitsRoutingModule } from './exhibits-routing.module';
import { SharedModule } from '../shared/shared.module';



@NgModule({
  declarations: [
    ExhibitsComponent,
    ExhibitDetailsComponent,
    ExhibitItemComponent
  ],
  imports: [
    CommonModule,
    ExhibitsRoutingModule,
    SharedModule
  ]
})
export class ExhibitsModule { }
